-- =============================================================
--  MICROSERVICIO: db_ms_clientes  (Base de Datos de Personas)
--  Base de datos propia · Oracle 21c
--
--  Sin referencias externas. Fuente de verdad de personas.
--  Todos los demas servicios referencian id_cliente como
--  Ref Ext hacia esta base de datos.
-- =============================================================

CREATE SEQUENCE seq_tipo_documento START WITH 1 NOCACHE ORDER;
CREATE SEQUENCE seq_cliente        START WITH 1 NOCACHE ORDER;

-- ----

CREATE TABLE tipo_documento (
    id_tipo_doc NUMBER(10)   DEFAULT seq_tipo_documento.NEXTVAL NOT NULL,
    codigo      VARCHAR2(10) NOT NULL,
    descripcion VARCHAR2(60) NOT NULL,
    CONSTRAINT pk_tipo_documento        PRIMARY KEY (id_tipo_doc),
    CONSTRAINT uq_tipo_documento_codigo UNIQUE      (codigo)
);

COMMENT ON TABLE tipo_documento IS 'Tipos de documento de identidad validos (RUT, Pasaporte, etc.)';

CREATE OR REPLACE TRIGGER tipo_documento_trg
BEFORE INSERT ON tipo_documento FOR EACH ROW WHEN (new.id_tipo_doc IS NULL)
BEGIN :new.id_tipo_doc := seq_tipo_documento.nextval; END;
/

-- ----

CREATE TABLE cliente (
    id_cliente    NUMBER(10)    DEFAULT seq_cliente.NEXTVAL NOT NULL,
    id_tipo_doc   NUMBER(10)    NOT NULL,
    nro_documento VARCHAR2(20)  NOT NULL,
    nombre        VARCHAR2(80)  NOT NULL,
    apellido      VARCHAR2(80)  NOT NULL,
    email         VARCHAR2(120),
    telefono      VARCHAR2(20),
    CONSTRAINT pk_cliente           PRIMARY KEY (id_cliente),
    CONSTRAINT uq_cliente_documento UNIQUE      (nro_documento),
    CONSTRAINT fk_cliente_tipo_doc  FOREIGN KEY (id_tipo_doc) REFERENCES tipo_documento (id_tipo_doc)
);

COMMENT ON TABLE cliente IS 'Personas registradas como clientes';

CREATE INDEX idx_cliente_tipo_doc ON cliente (id_tipo_doc);

CREATE OR REPLACE TRIGGER cliente_trg
BEFORE INSERT ON cliente FOR EACH ROW WHEN (new.id_cliente IS NULL)
BEGIN :new.id_cliente := seq_cliente.nextval; END;
/

-- =============================================================
--  RESUMEN: 2 tablas · 2 sequences · 2 triggers · 1 índice
-- =============================================================
