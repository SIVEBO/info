-- =============================================================
--  MICROSERVICIO: db_ms_admision  (Ingreso de Carga)
--  Base de datos propia · Oracle 21c
--
--  Referencias externas (Ref Ext — sin FK formal):
--    ADMISION.id_cliente_rem     → db_ms_clientes.CLIENTE
--    ADMISION.id_cliente_dest    → db_ms_clientes.CLIENTE
--    ADMISION.id_sucursal_origen → db_ms_sucursales.SUCURSAL
--    ADMISION.id_sucursal_dest   → db_ms_sucursales.SUCURSAL
--    ADMISION.id_usuario_reg     → db_ms_auth.USUARIO
-- =============================================================

CREATE SEQUENCE seq_tipo_carga START WITH 1 NOCACHE ORDER;
CREATE SEQUENCE seq_admision   START WITH 1 NOCACHE ORDER;

-- ----

CREATE TABLE tipo_carga (
    id_tipo     NUMBER(10)   DEFAULT seq_tipo_carga.NEXTVAL NOT NULL,
    nombre_tipo VARCHAR2(60) NOT NULL,
    descripcion CLOB,
    CONSTRAINT pk_tipo_carga        PRIMARY KEY (id_tipo),
    CONSTRAINT uq_tipo_carga_nombre UNIQUE      (nombre_tipo)
);

COMMENT ON TABLE tipo_carga IS 'Categorias de carga admitida (Documento, Encomienda, etc.)';

CREATE OR REPLACE TRIGGER tipo_carga_trg
BEFORE INSERT ON tipo_carga FOR EACH ROW WHEN (new.id_tipo IS NULL)
BEGIN :new.id_tipo := seq_tipo_carga.nextval; END;
/

-- ----

CREATE TABLE admision (
    id_admision        NUMBER(10)               DEFAULT seq_admision.NEXTVAL NOT NULL,
    id_cliente_rem     NUMBER(10)               NOT NULL,  -- Ref Ext → db_ms_clientes.CLIENTE
    id_cliente_dest    NUMBER(10)               NOT NULL,  -- Ref Ext → db_ms_clientes.CLIENTE
    id_sucursal_origen NUMBER(10)               NOT NULL,  -- Ref Ext → db_ms_sucursales.SUCURSAL
    id_sucursal_dest   NUMBER(10)               NOT NULL,  -- Ref Ext → db_ms_sucursales.SUCURSAL
    id_tipo            NUMBER(10)               NOT NULL,
    peso_kg            NUMBER(8, 3)             NOT NULL,
    fecha_creacion     TIMESTAMP WITH TIME ZONE DEFAULT SYSTIMESTAMP NOT NULL,
    id_usuario_reg     NUMBER(10)               NOT NULL,  -- Ref Ext → db_ms_auth.USUARIO
    CONSTRAINT pk_admision       PRIMARY KEY (id_admision),
    CONSTRAINT fk_admision_tipo  FOREIGN KEY (id_tipo) REFERENCES tipo_carga (id_tipo)
);

COMMENT ON TABLE  admision                  IS 'Registro de ingreso de encomiendas';
COMMENT ON COLUMN admision.id_cliente_rem   IS 'Ref Ext: id en db_ms_clientes.CLIENTE (remitente)';
COMMENT ON COLUMN admision.id_cliente_dest  IS 'Ref Ext: id en db_ms_clientes.CLIENTE (destinatario)';
COMMENT ON COLUMN admision.id_sucursal_origen IS 'Ref Ext: id en db_ms_sucursales.SUCURSAL';
COMMENT ON COLUMN admision.id_sucursal_dest IS 'Ref Ext: id en db_ms_sucursales.SUCURSAL';
COMMENT ON COLUMN admision.id_usuario_reg   IS 'Ref Ext: id en db_ms_auth.USUARIO';

CREATE INDEX idx_admision_cliente_rem  ON admision (id_cliente_rem);
CREATE INDEX idx_admision_cliente_dest ON admision (id_cliente_dest);
CREATE INDEX idx_admision_suc_origen   ON admision (id_sucursal_origen);
CREATE INDEX idx_admision_suc_dest     ON admision (id_sucursal_dest);
CREATE INDEX idx_admision_fecha        ON admision (fecha_creacion DESC);

CREATE OR REPLACE TRIGGER admision_trg
BEFORE INSERT ON admision FOR EACH ROW WHEN (new.id_admision IS NULL)
BEGIN :new.id_admision := seq_admision.nextval; END;
/

-- =============================================================
--  RESUMEN: 2 tablas · 2 sequences · 2 triggers · 5 índices
-- =============================================================
