-- =============================================================
--  MICROSERVICIO: db_ms_inv_embalaje  (Materiales de Venta)
--  Base de datos propia · Oracle 21c
--
--  Referencias externas (Ref Ext — sin FK formal):
--    STOCK_SUCURSAL.id_sucursal → db_ms_sucursales.SUCURSAL
-- =============================================================

CREATE SEQUENCE seq_categoria_embalaje START WITH 1 NOCACHE ORDER;
CREATE SEQUENCE seq_articulo_embalaje  START WITH 1 NOCACHE ORDER;
CREATE SEQUENCE seq_stock_sucursal     START WITH 1 NOCACHE ORDER;

-- ----

CREATE TABLE categoria_embalaje (
    id_cat           NUMBER(10)   DEFAULT seq_categoria_embalaje.NEXTVAL NOT NULL,
    nombre_categoria VARCHAR2(60) NOT NULL,
    CONSTRAINT pk_categoria_embalaje        PRIMARY KEY (id_cat),
    CONSTRAINT uq_categoria_embalaje_nombre UNIQUE      (nombre_categoria)
);

COMMENT ON TABLE categoria_embalaje IS 'Categorias de materiales de embalaje (Cajas, Sobres, etc.)';

CREATE OR REPLACE TRIGGER categoria_embalaje_trg
BEFORE INSERT ON categoria_embalaje FOR EACH ROW WHEN (new.id_cat IS NULL)
BEGIN :new.id_cat := seq_categoria_embalaje.nextval; END;
/

-- ----

CREATE TABLE articulo_embalaje (
    id_art      NUMBER(10)    DEFAULT seq_articulo_embalaje.NEXTVAL NOT NULL,
    id_cat      NUMBER(10)    NOT NULL,
    nombre      VARCHAR2(120) NOT NULL,
    descripcion CLOB,
    precio_vta  NUMBER(10, 2) NOT NULL,
    activo      NUMBER(1)    DEFAULT 1 NOT NULL,
    CONSTRAINT pk_articulo_embalaje          PRIMARY KEY (id_art),
    CONSTRAINT ck_articulo_embalaje_activo   CHECK       (activo IN (0, 1)),
    CONSTRAINT ck_articulo_embalaje_precio   CHECK       (precio_vta >= 0),
    CONSTRAINT fk_articulo_embalaje_categoria FOREIGN KEY (id_cat) REFERENCES categoria_embalaje (id_cat)
);

COMMENT ON TABLE articulo_embalaje IS 'Articulos de embalaje disponibles para venta';

CREATE INDEX idx_art_categoria ON articulo_embalaje (id_cat);

CREATE OR REPLACE TRIGGER articulo_embalaje_trg
BEFORE INSERT ON articulo_embalaje FOR EACH ROW WHEN (new.id_art IS NULL)
BEGIN :new.id_art := seq_articulo_embalaje.nextval; END;
/

-- ----

CREATE TABLE stock_sucursal (
    id_stock            NUMBER(10)               DEFAULT seq_stock_sucursal.NEXTVAL NOT NULL,
    id_art              NUMBER(10)               NOT NULL,
    id_sucursal         NUMBER(10)               NOT NULL,  -- Ref Ext → db_ms_sucursales.SUCURSAL
    cantidad_disponible NUMBER(10)               DEFAULT 0 NOT NULL,
    updated_at          TIMESTAMP WITH TIME ZONE DEFAULT SYSTIMESTAMP NOT NULL,
    CONSTRAINT pk_stock_sucursal          PRIMARY KEY (id_stock),
    CONSTRAINT uq_stock_sucursal_art_suc  UNIQUE      (id_art, id_sucursal),
    CONSTRAINT ck_stock_sucursal_cantidad CHECK       (cantidad_disponible >= 0),
    CONSTRAINT fk_stock_sucursal_articulo FOREIGN KEY (id_art) REFERENCES articulo_embalaje (id_art)
);

COMMENT ON TABLE  stock_sucursal            IS 'Stock de articulos de embalaje por sucursal. UNIQUE(id_art, id_sucursal)';
COMMENT ON COLUMN stock_sucursal.id_sucursal IS 'Ref Ext: id en db_ms_sucursales.SUCURSAL';
COMMENT ON COLUMN stock_sucursal.updated_at  IS 'Actualizado automaticamente via trigger en cada UPDATE';

CREATE INDEX idx_stock_art      ON stock_sucursal (id_art);
CREATE INDEX idx_stock_sucursal ON stock_sucursal (id_sucursal);

CREATE OR REPLACE TRIGGER stock_sucursal_trg
BEFORE INSERT ON stock_sucursal FOR EACH ROW WHEN (new.id_stock IS NULL)
BEGIN :new.id_stock := seq_stock_sucursal.nextval; END;
/

CREATE OR REPLACE TRIGGER trg_stock_sucursal_updated_at
BEFORE UPDATE ON stock_sucursal FOR EACH ROW
BEGIN :new.updated_at := SYSTIMESTAMP; END;
/

-- =============================================================
--  RESUMEN: 3 tablas · 3 sequences · 4 triggers · 3 índices
-- =============================================================
