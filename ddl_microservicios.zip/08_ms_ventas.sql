-- =============================================================
--  MICROSERVICIO: db_ms_ventas  (Transacciones POS)
--  Base de datos propia · Oracle 21c
--
--  Referencias externas (Ref Ext — sin FK formal):
--    VENTA.id_usuario          → db_ms_auth.USUARIO
--    VENTA.id_sucursal         → db_ms_sucursales.SUCURSAL
--    DETALLE_VENTA.id_articulo → db_ms_inv_embalaje.ARTICULO_EMBALAJE
--    DETALLE_VENTA.id_admision → db_ms_admision.ADMISION
-- =============================================================

CREATE SEQUENCE seq_venta         START WITH 1 NOCACHE ORDER;
CREATE SEQUENCE seq_detalle_venta START WITH 1 NOCACHE ORDER;

-- ----

CREATE TABLE venta (
    id_venta    NUMBER(10)               DEFAULT seq_venta.NEXTVAL NOT NULL,
    nro_boleta  VARCHAR2(20)             NOT NULL,
    id_usuario  NUMBER(10)               NOT NULL,  -- Ref Ext → db_ms_auth.USUARIO
    id_sucursal NUMBER(10)               NOT NULL,  -- Ref Ext → db_ms_sucursales.SUCURSAL
    fecha_vta   TIMESTAMP WITH TIME ZONE DEFAULT SYSTIMESTAMP NOT NULL,
    subtotal    NUMBER(12, 2)            NOT NULL,
    iva         NUMBER(12, 2)            NOT NULL,
    total       NUMBER(12, 2)            NOT NULL,
    estado      VARCHAR2(20)             DEFAULT 'ACTIVA' NOT NULL,
    CONSTRAINT pk_venta          PRIMARY KEY (id_venta),
    CONSTRAINT uq_venta_boleta   UNIQUE      (nro_boleta),
    CONSTRAINT ck_venta_estado   CHECK       (estado IN ('ACTIVA', 'ANULADA', 'PENDIENTE')),
    CONSTRAINT ck_venta_subtotal CHECK       (subtotal >= 0),
    CONSTRAINT ck_venta_total    CHECK       (total >= 0)
);

COMMENT ON TABLE  venta             IS 'Transacciones POS realizadas en sucursal';
COMMENT ON COLUMN venta.id_usuario  IS 'Ref Ext: id en db_ms_auth.USUARIO';
COMMENT ON COLUMN venta.id_sucursal IS 'Ref Ext: id en db_ms_sucursales.SUCURSAL';

CREATE INDEX idx_venta_usuario  ON venta (id_usuario);
CREATE INDEX idx_venta_sucursal ON venta (id_sucursal);
CREATE INDEX idx_venta_fecha    ON venta (fecha_vta DESC);

CREATE OR REPLACE TRIGGER venta_trg
BEFORE INSERT ON venta FOR EACH ROW WHEN (new.id_venta IS NULL)
BEGIN :new.id_venta := seq_venta.nextval; END;
/

-- ----

CREATE TABLE detalle_venta (
    id_det                    NUMBER(10)    DEFAULT seq_detalle_venta.NEXTVAL NOT NULL,
    id_venta                  NUMBER(10)    NOT NULL,
    id_articulo               NUMBER(10)    NOT NULL,  -- Ref Ext → db_ms_inv_embalaje.ARTICULO_EMBALAJE
    id_admision               NUMBER(10),              -- Ref Ext → db_ms_admision.ADMISION (nullable)
    cantidad_art              NUMBER(10)    NOT NULL,
    precio_unit_historico_art NUMBER(10, 2) NOT NULL,
    precio_admision           NUMBER(10, 2),
    CONSTRAINT pk_detalle_venta          PRIMARY KEY (id_det),
    CONSTRAINT ck_detalle_venta_cantidad CHECK       (cantidad_art              > 0),
    CONSTRAINT ck_detalle_venta_precio   CHECK       (precio_unit_historico_art >= 0),
    CONSTRAINT fk_detalle_venta_venta    FOREIGN KEY (id_venta) REFERENCES venta (id_venta) ON DELETE CASCADE
);

COMMENT ON TABLE  detalle_venta              IS 'Lineas de detalle de cada venta (embalaje y/o servicio de envio)';
COMMENT ON COLUMN detalle_venta.id_articulo  IS 'Ref Ext: id en db_ms_inv_embalaje.ARTICULO_EMBALAJE';
COMMENT ON COLUMN detalle_venta.id_admision  IS 'Ref Ext: id en db_ms_admision.ADMISION. Nullable: solo si la linea es un servicio de envio';
COMMENT ON COLUMN detalle_venta.precio_admision IS 'Precio del servicio de envio. Nullable: NULL si la linea es solo embalaje';

CREATE INDEX idx_det_venta    ON detalle_venta (id_venta);
CREATE INDEX idx_det_articulo ON detalle_venta (id_articulo);
CREATE INDEX idx_det_admision ON detalle_venta (id_admision);

CREATE OR REPLACE TRIGGER detalle_venta_trg
BEFORE INSERT ON detalle_venta FOR EACH ROW WHEN (new.id_det IS NULL)
BEGIN :new.id_det := seq_detalle_venta.nextval; END;
/

-- =============================================================
--  RESUMEN: 2 tablas · 2 sequences · 2 triggers · 6 índices
-- =============================================================
