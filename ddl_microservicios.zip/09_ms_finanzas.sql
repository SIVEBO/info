-- =============================================================
--  MICROSERVICIO: db_ms_finanzas  (Caja y Reportes)
--  Base de datos propia · Oracle 21c
--
--  Referencias externas (Ref Ext — sin FK formal):
--    CAJA_SUCURSAL.id_sucursal    → db_ms_sucursales.SUCURSAL
--    APERTURA_CIERRE.id_usuario   → db_ms_auth.USUARIO
--    MOVIMIENTO_CAJA.id_venta     → db_ms_ventas.VENTA
-- =============================================================

CREATE SEQUENCE seq_caja_sucursal  START WITH 1 NOCACHE ORDER;
CREATE SEQUENCE seq_apertura_cierre START WITH 1 NOCACHE ORDER;
CREATE SEQUENCE seq_movimiento_caja START WITH 1 NOCACHE ORDER;

-- ----

CREATE TABLE caja_sucursal (
    id_caja       NUMBER(10)   DEFAULT seq_caja_sucursal.NEXTVAL NOT NULL,
    id_sucursal   NUMBER(10)   NOT NULL,  -- Ref Ext → db_ms_sucursales.SUCURSAL
    estado_actual VARCHAR2(20) DEFAULT 'CERRADA' NOT NULL,
    CONSTRAINT pk_caja_sucursal         PRIMARY KEY (id_caja),
    CONSTRAINT uq_caja_sucursal_sucursal UNIQUE     (id_sucursal),
    CONSTRAINT ck_caja_sucursal_estado  CHECK       (estado_actual IN ('ABIERTA', 'CERRADA'))
);

COMMENT ON TABLE  caja_sucursal             IS 'Caja registradora por sucursal (1:1)';
COMMENT ON COLUMN caja_sucursal.id_sucursal IS 'Ref Ext: id en db_ms_sucursales.SUCURSAL';

CREATE INDEX idx_caja_sucursal ON caja_sucursal (id_sucursal);

CREATE OR REPLACE TRIGGER caja_sucursal_trg
BEFORE INSERT ON caja_sucursal FOR EACH ROW WHEN (new.id_caja IS NULL)
BEGIN :new.id_caja := seq_caja_sucursal.nextval; END;
/

-- ----

CREATE TABLE apertura_cierre (
    id_sesion      NUMBER(10)               DEFAULT seq_apertura_cierre.NEXTVAL NOT NULL,
    id_caja        NUMBER(10)               NOT NULL,
    id_usuario     NUMBER(10)               NOT NULL,  -- Ref Ext → db_ms_auth.USUARIO
    monto_apertura NUMBER(12, 2)            NOT NULL,
    monto_cierre   NUMBER(12, 2),
    fecha_hora_ap  TIMESTAMP WITH TIME ZONE DEFAULT SYSTIMESTAMP NOT NULL,
    fecha_hora_ci  TIMESTAMP WITH TIME ZONE,
    CONSTRAINT pk_apertura_cierre          PRIMARY KEY (id_sesion),
    CONSTRAINT ck_apertura_cierre_monto_ap CHECK       (monto_apertura >= 0),
    CONSTRAINT fk_apertura_cierre_caja     FOREIGN KEY (id_caja) REFERENCES caja_sucursal (id_caja)
);

COMMENT ON TABLE  apertura_cierre            IS 'Sesiones de caja: apertura y cierre';
COMMENT ON COLUMN apertura_cierre.id_usuario IS 'Ref Ext: id en db_ms_auth.USUARIO';

CREATE INDEX idx_apertura_caja  ON apertura_cierre (id_caja);
CREATE INDEX idx_apertura_fecha ON apertura_cierre (fecha_hora_ap DESC);

CREATE OR REPLACE TRIGGER apertura_cierre_trg
BEFORE INSERT ON apertura_cierre FOR EACH ROW WHEN (new.id_sesion IS NULL)
BEGIN :new.id_sesion := seq_apertura_cierre.nextval; END;
/

-- ----

CREATE TABLE movimiento_caja (
    id_mov    NUMBER(10)    DEFAULT seq_movimiento_caja.NEXTVAL NOT NULL,
    id_sesion NUMBER(10)    NOT NULL,
    tipo      VARCHAR2(10)  NOT NULL,
    monto     NUMBER(12, 2) NOT NULL,
    id_venta  NUMBER(10),              -- Ref Ext → db_ms_ventas.VENTA (nullable)
    concepto  CLOB,
    CONSTRAINT pk_movimiento_caja        PRIMARY KEY (id_mov),
    CONSTRAINT ck_movimiento_caja_tipo   CHECK       (tipo IN ('INGRESO', 'EGRESO')),
    CONSTRAINT ck_movimiento_caja_monto  CHECK       (monto > 0),
    CONSTRAINT fk_movimiento_caja_sesion FOREIGN KEY (id_sesion) REFERENCES apertura_cierre (id_sesion)
);

COMMENT ON TABLE  movimiento_caja          IS 'Movimientos de ingreso y egreso por sesion de caja';
COMMENT ON COLUMN movimiento_caja.id_venta IS 'Ref Ext: id en db_ms_ventas.VENTA. Nullable: NULL para movimientos manuales';

CREATE INDEX idx_mov_sesion ON movimiento_caja (id_sesion);
CREATE INDEX idx_mov_venta  ON movimiento_caja (id_venta);

CREATE OR REPLACE TRIGGER movimiento_caja_trg
BEFORE INSERT ON movimiento_caja FOR EACH ROW WHEN (new.id_mov IS NULL)
BEGIN :new.id_mov := seq_movimiento_caja.nextval; END;
/

-- =============================================================
--  RESUMEN: 3 tablas · 3 sequences · 3 triggers · 5 índices
-- =============================================================
