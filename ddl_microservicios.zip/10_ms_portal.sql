-- =============================================================
--  MICROSERVICIO: db_ms_portal  (Consultas Públicas y Feedback)
--  Base de datos propia · Oracle 21c
--
--  Referencias externas (Ref Ext — sin FK formal):
--    CONSULTA_PUBLICA.id_guia   → db_ms_tracking.GUIA_DESPACHO
--    FEEDBACK_CLIENTE.id_guia   → db_ms_tracking.GUIA_DESPACHO
--    FEEDBACK_CLIENTE.id_cliente → db_ms_clientes.CLIENTE
-- =============================================================

CREATE SEQUENCE seq_consulta_publica START WITH 1 NOCACHE ORDER;
CREATE SEQUENCE seq_feedback_cliente START WITH 1 NOCACHE ORDER;

-- ----

CREATE TABLE consulta_publica (
    id_cons                    NUMBER(10)               DEFAULT seq_consulta_publica.NEXTVAL NOT NULL,
    codigo_tracking_consultado VARCHAR2(30)             NOT NULL,
    id_guia                    NUMBER(10),              -- Ref Ext → db_ms_tracking.GUIA_DESPACHO (nullable)
    ip_usuario                 VARCHAR2(45)             NOT NULL,
    fecha_hora                 TIMESTAMP WITH TIME ZONE DEFAULT SYSTIMESTAMP NOT NULL,
    CONSTRAINT pk_consulta_publica PRIMARY KEY (id_cons)
);

COMMENT ON TABLE  consulta_publica         IS 'Log de consultas de tracking desde el portal publico';
COMMENT ON COLUMN consulta_publica.id_guia IS 'Ref Ext: id en db_ms_tracking.GUIA_DESPACHO. Nullable: NULL cuando el codigo no existe';

CREATE INDEX idx_consulta_guia     ON consulta_publica (id_guia);
CREATE INDEX idx_consulta_tracking ON consulta_publica (codigo_tracking_consultado);
CREATE INDEX idx_consulta_fecha    ON consulta_publica (fecha_hora DESC);

CREATE OR REPLACE TRIGGER consulta_publica_trg
BEFORE INSERT ON consulta_publica FOR EACH ROW WHEN (new.id_cons IS NULL)
BEGIN :new.id_cons := seq_consulta_publica.nextval; END;
/

-- ----

CREATE TABLE feedback_cliente (
    id_feed      NUMBER(10)               DEFAULT seq_feedback_cliente.NEXTVAL NOT NULL,
    id_guia      NUMBER(10)               NOT NULL,  -- Ref Ext → db_ms_tracking.GUIA_DESPACHO
    id_cliente   NUMBER(10),                          -- Ref Ext → db_ms_clientes.CLIENTE (nullable)
    calificacion NUMBER(1)               NOT NULL,
    comentario   CLOB,
    fecha_hora   TIMESTAMP WITH TIME ZONE DEFAULT SYSTIMESTAMP NOT NULL,
    CONSTRAINT pk_feedback_cliente              PRIMARY KEY (id_feed),
    CONSTRAINT ck_feedback_cliente_calificacion CHECK       (calificacion BETWEEN 1 AND 5)
);

COMMENT ON TABLE  feedback_cliente            IS 'Calificaciones y comentarios sobre guias';
COMMENT ON COLUMN feedback_cliente.id_guia    IS 'Ref Ext: id en db_ms_tracking.GUIA_DESPACHO';
COMMENT ON COLUMN feedback_cliente.id_cliente IS 'Ref Ext: id en db_ms_clientes.CLIENTE. Nullable: permite feedback anonimo';

CREATE INDEX idx_feedback_guia    ON feedback_cliente (id_guia);
CREATE INDEX idx_feedback_cliente ON feedback_cliente (id_cliente);

CREATE OR REPLACE TRIGGER feedback_cliente_trg
BEFORE INSERT ON feedback_cliente FOR EACH ROW WHEN (new.id_feed IS NULL)
BEGIN :new.id_feed := seq_feedback_cliente.nextval; END;
/

-- ----

CREATE OR REPLACE VIEW v_consulta_publica (
    id_cons, codigo_tracking_consultado,
    id_guia, guia_encontrada, ip_usuario, fecha_hora
) AS
SELECT
    id_cons,
    codigo_tracking_consultado,
    id_guia,
    CASE WHEN id_guia IS NOT NULL THEN 1 ELSE 0 END AS guia_encontrada,
    ip_usuario,
    fecha_hora
FROM consulta_publica;

-- =============================================================
--  RESUMEN: 2 tablas · 1 vista · 2 sequences · 2 triggers
--           5 índices
-- =============================================================
