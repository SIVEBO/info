-- =============================================================
--  MICROSERVICIO: db_ms_sucursales  (Configuración de Red)
--  Base de datos propia · Oracle 21c
--
--  Sin referencias externas. Fuente de verdad para la red
--  geografica. Todos los demas servicios referencian
--  id_sucursal como Ref Ext hacia esta base de datos.
-- =============================================================

CREATE SEQUENCE seq_region   START WITH 1 NOCACHE ORDER;
CREATE SEQUENCE seq_comuna   START WITH 1 NOCACHE ORDER;
CREATE SEQUENCE seq_sucursal START WITH 1 NOCACHE ORDER;

-- ----

CREATE TABLE region (
    id_region     NUMBER(10)   DEFAULT seq_region.NEXTVAL NOT NULL,
    nombre_region VARCHAR2(80) NOT NULL,
    CONSTRAINT pk_region        PRIMARY KEY (id_region),
    CONSTRAINT uq_region_nombre UNIQUE      (nombre_region)
);

COMMENT ON TABLE region IS 'Regiones geograficas del pais';

CREATE OR REPLACE TRIGGER region_trg
BEFORE INSERT ON region FOR EACH ROW WHEN (new.id_region IS NULL)
BEGIN :new.id_region := seq_region.nextval; END;
/

-- ----

CREATE TABLE comuna (
    id_comuna     NUMBER(10)   DEFAULT seq_comuna.NEXTVAL NOT NULL,
    nombre_comuna VARCHAR2(80) NOT NULL,
    id_region     NUMBER(10)   NOT NULL,
    CONSTRAINT pk_comuna        PRIMARY KEY (id_comuna),
    CONSTRAINT fk_comuna_region FOREIGN KEY (id_region) REFERENCES region (id_region)
);

COMMENT ON TABLE comuna IS 'Comunas pertenecientes a una region';

CREATE INDEX idx_comuna_region ON comuna (id_region);

CREATE OR REPLACE TRIGGER comuna_trg
BEFORE INSERT ON comuna FOR EACH ROW WHEN (new.id_comuna IS NULL)
BEGIN :new.id_comuna := seq_comuna.nextval; END;
/

-- ----

CREATE TABLE sucursal (
    id_sucursal       NUMBER(10)    DEFAULT seq_sucursal.NEXTVAL NOT NULL,
    nombre_sucursal   VARCHAR2(100) NOT NULL,
    id_comuna         NUMBER(10)    NOT NULL,
    direccion_fisica  CLOB          NOT NULL,
    telefono_contacto VARCHAR2(20),
    activa            NUMBER(1)    DEFAULT 1 NOT NULL,
    CONSTRAINT pk_sucursal        PRIMARY KEY (id_sucursal),
    CONSTRAINT ck_sucursal_activa CHECK       (activa IN (0, 1)),
    CONSTRAINT fk_sucursal_comuna FOREIGN KEY (id_comuna) REFERENCES comuna (id_comuna)
);

COMMENT ON TABLE  sucursal        IS 'Sucursales fisicas de la empresa';
COMMENT ON COLUMN sucursal.activa IS 'NUMBER(1): 1=activa, 0=inactiva';

CREATE INDEX idx_sucursal_comuna ON sucursal (id_comuna);

CREATE OR REPLACE TRIGGER sucursal_trg
BEFORE INSERT ON sucursal FOR EACH ROW WHEN (new.id_sucursal IS NULL)
BEGIN :new.id_sucursal := seq_sucursal.nextval; END;
/

-- =============================================================
--  RESUMEN: 3 tablas · 3 sequences · 3 triggers · 2 índices
-- =============================================================
