-- =============================================================
--  MICROSERVICIO: db_ms_auth  (Usuarios y Seguridad)
--  Base de datos propia · Oracle 21c
--
--  Referencias externas (Ref Ext — sin FK formal):
--    USUARIO.id_sucursal_asignada → db_ms_sucursales.SUCURSAL
-- =============================================================

CREATE SEQUENCE seq_rol     START WITH 1 NOCACHE ORDER;
CREATE SEQUENCE seq_usuario START WITH 1 NOCACHE ORDER;
CREATE SEQUENCE seq_token   START WITH 1 NOCACHE ORDER;

-- ----

CREATE TABLE rol (
    id_rol      NUMBER(10)   DEFAULT seq_rol.NEXTVAL NOT NULL,
    nombre_rol  VARCHAR2(60) NOT NULL,
    descripcion CLOB,
    CONSTRAINT pk_rol        PRIMARY KEY (id_rol),
    CONSTRAINT uq_rol_nombre UNIQUE      (nombre_rol)
);

COMMENT ON TABLE rol IS 'Roles de acceso del sistema';

CREATE OR REPLACE TRIGGER rol_trg
BEFORE INSERT ON rol FOR EACH ROW WHEN (new.id_rol IS NULL)
BEGIN :new.id_rol := seq_rol.nextval; END;
/

-- ----

CREATE TABLE usuario (
    id_usuario           NUMBER(10)               DEFAULT seq_usuario.NEXTVAL NOT NULL,
    username             VARCHAR2(60)             NOT NULL,
    password_hash        CHAR(60)                 NOT NULL,
    email                VARCHAR2(120)            NOT NULL,
    id_rol               NUMBER(10)               NOT NULL,
    id_sucursal_asignada NUMBER(10),               -- Ref Ext → db_ms_sucursales.SUCURSAL
    activo               NUMBER(1)                DEFAULT 1 NOT NULL,
    created_at           TIMESTAMP WITH TIME ZONE DEFAULT SYSTIMESTAMP NOT NULL,
    CONSTRAINT pk_usuario          PRIMARY KEY (id_usuario),
    CONSTRAINT uq_usuario_username UNIQUE      (username),
    CONSTRAINT uq_usuario_email    UNIQUE      (email),
    CONSTRAINT ck_usuario_activo   CHECK       (activo IN (0, 1)),
    CONSTRAINT fk_usuario_rol      FOREIGN KEY (id_rol) REFERENCES rol (id_rol)
);

COMMENT ON TABLE  usuario                    IS 'Usuarios con acceso al sistema';
COMMENT ON COLUMN usuario.activo             IS 'NUMBER(1): 1=activo, 0=inactivo';
COMMENT ON COLUMN usuario.id_sucursal_asignada IS 'Ref Ext: id en db_ms_sucursales.SUCURSAL';

CREATE INDEX idx_usuario_rol      ON usuario (id_rol);
CREATE INDEX idx_usuario_sucursal ON usuario (id_sucursal_asignada);

CREATE OR REPLACE TRIGGER usuario_trg
BEFORE INSERT ON usuario FOR EACH ROW WHEN (new.id_usuario IS NULL)
BEGIN :new.id_usuario := seq_usuario.nextval; END;
/

-- ----

CREATE TABLE token_sesion (
    id_token         NUMBER(10)               DEFAULT seq_token.NEXTVAL NOT NULL,
    id_usuario       NUMBER(10)               NOT NULL,
    token            VARCHAR2(512)            NOT NULL,
    fecha_expiracion TIMESTAMP WITH TIME ZONE NOT NULL,
    created_at       TIMESTAMP WITH TIME ZONE DEFAULT SYSTIMESTAMP NOT NULL,
    CONSTRAINT pk_token_sesion       PRIMARY KEY (id_token),
    CONSTRAINT uq_token_sesion_token UNIQUE      (token),
    CONSTRAINT fk_token_usuario      FOREIGN KEY (id_usuario) REFERENCES usuario (id_usuario) ON DELETE CASCADE
);

COMMENT ON TABLE token_sesion IS 'Tokens de sesion activos por usuario';

CREATE INDEX idx_token_usuario    ON token_sesion (id_usuario);
CREATE INDEX idx_token_expiracion ON token_sesion (fecha_expiracion);

CREATE OR REPLACE TRIGGER token_trg
BEFORE INSERT ON token_sesion FOR EACH ROW WHEN (new.id_token IS NULL)
BEGIN :new.id_token := seq_token.nextval; END;
/

-- =============================================================
--  RESUMEN: 3 tablas · 3 sequences · 3 triggers · 3 índices
-- =============================================================
