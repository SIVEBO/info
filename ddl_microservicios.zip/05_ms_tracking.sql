-- =============================================================
--  MICROSERVICIO: db_ms_tracking  (Logística y Estados)
--  Base de datos propia · Oracle 21c
--
--  Referencias externas (Ref Ext — sin FK formal):
--    GUIA_DESPACHO.id_admision         → db_ms_admision.ADMISION
--    HISTORIAL_LOGISTICO.id_sucursal_actual → db_ms_sucursales.SUCURSAL
--    HISTORIAL_LOGISTICO.id_usuario    → db_ms_auth.USUARIO
-- =============================================================

CREATE SEQUENCE seq_estado_maestro      START WITH 1 NOCACHE ORDER;
CREATE SEQUENCE seq_guia_despacho       START WITH 1 NOCACHE ORDER;
CREATE SEQUENCE seq_historial_logistico START WITH 1 NOCACHE ORDER;

-- ----

CREATE TABLE estado_maestro (
    id_estado     NUMBER(10)   DEFAULT seq_estado_maestro.NEXTVAL NOT NULL,
    nombre_estado VARCHAR2(60) NOT NULL,
    orden         NUMBER(5)    NOT NULL,
    CONSTRAINT pk_estado_maestro        PRIMARY KEY (id_estado),
    CONSTRAINT uq_estado_maestro_nombre UNIQUE      (nombre_estado)
);

COMMENT ON TABLE estado_maestro IS 'Estados posibles de una guia de despacho (Recibido, En Transito, Entregado, etc.)';

CREATE OR REPLACE TRIGGER estado_maestro_trg
BEFORE INSERT ON estado_maestro FOR EACH ROW WHEN (new.id_estado IS NULL)
BEGIN :new.id_estado := seq_estado_maestro.nextval; END;
/

-- ----

CREATE TABLE guia_despacho (
    id_guia         NUMBER(10)               DEFAULT seq_guia_despacho.NEXTVAL NOT NULL,
    codigo_tracking VARCHAR2(30)             NOT NULL,
    id_admision     NUMBER(10)               NOT NULL,  -- Ref Ext → db_ms_admision.ADMISION
    fecha_creacion  TIMESTAMP WITH TIME ZONE DEFAULT SYSTIMESTAMP NOT NULL,
    CONSTRAINT pk_guia_despacho          PRIMARY KEY (id_guia),
    CONSTRAINT uq_guia_despacho_tracking UNIQUE      (codigo_tracking)
);

COMMENT ON TABLE  guia_despacho             IS 'Guia de despacho generada por admision';
COMMENT ON COLUMN guia_despacho.id_admision IS 'Ref Ext: id en db_ms_admision.ADMISION';

CREATE INDEX idx_guia_admision ON guia_despacho (id_admision);

CREATE OR REPLACE TRIGGER guia_despacho_trg
BEFORE INSERT ON guia_despacho FOR EACH ROW WHEN (new.id_guia IS NULL)
BEGIN :new.id_guia := seq_guia_despacho.nextval; END;
/

-- ----

CREATE TABLE historial_logistico (
    id_hist            NUMBER(10)               DEFAULT seq_historial_logistico.NEXTVAL NOT NULL,
    id_guia            NUMBER(10)               NOT NULL,
    id_estado          NUMBER(10)               NOT NULL,
    id_sucursal_actual NUMBER(10)               NOT NULL,  -- Ref Ext → db_ms_sucursales.SUCURSAL
    id_usuario         NUMBER(10)               NOT NULL,  -- Ref Ext → db_ms_auth.USUARIO
    fecha_hora         TIMESTAMP WITH TIME ZONE DEFAULT SYSTIMESTAMP NOT NULL,
    comentario         CLOB,
    CONSTRAINT pk_historial_logistico PRIMARY KEY (id_hist),
    CONSTRAINT fk_hist_guia           FOREIGN KEY (id_guia)   REFERENCES guia_despacho  (id_guia),
    CONSTRAINT fk_hist_estado         FOREIGN KEY (id_estado) REFERENCES estado_maestro (id_estado)
);

COMMENT ON TABLE  historial_logistico                  IS 'Trazabilidad de estados por guia (fuente de verdad del estado actual)';
COMMENT ON COLUMN historial_logistico.id_sucursal_actual IS 'Ref Ext: id en db_ms_sucursales.SUCURSAL';
COMMENT ON COLUMN historial_logistico.id_usuario         IS 'Ref Ext: id en db_ms_auth.USUARIO';

CREATE INDEX idx_hist_guia     ON historial_logistico (id_guia);
CREATE INDEX idx_hist_estado   ON historial_logistico (id_estado);
CREATE INDEX idx_hist_fecha    ON historial_logistico (fecha_hora DESC);
CREATE INDEX idx_hist_sucursal ON historial_logistico (id_sucursal_actual);

CREATE OR REPLACE TRIGGER historial_logistico_trg
BEFORE INSERT ON historial_logistico FOR EACH ROW WHEN (new.id_hist IS NULL)
BEGIN :new.id_hist := seq_historial_logistico.nextval; END;
/

-- ----

CREATE OR REPLACE VIEW v_estado_actual_guia (
    id_guia, id_estado, nombre_estado,
    fecha_ultimo_estado, id_sucursal_actual,
    id_usuario_responsable, comentario
) AS
SELECT
    h.id_guia,
    h.id_estado,
    e.nombre_estado,
    h.fecha_hora         AS fecha_ultimo_estado,
    h.id_sucursal_actual,
    h.id_usuario         AS id_usuario_responsable,
    h.comentario
FROM historial_logistico h
JOIN estado_maestro e ON e.id_estado = h.id_estado
WHERE h.fecha_hora = (
    SELECT MAX(h2.fecha_hora)
    FROM historial_logistico h2
    WHERE h2.id_guia = h.id_guia
);

-- =============================================================
--  RESUMEN: 3 tablas · 1 vista · 3 sequences · 3 triggers
--           6 índices
-- =============================================================
