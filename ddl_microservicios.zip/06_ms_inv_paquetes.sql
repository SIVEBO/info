-- =============================================================
--  MICROSERVICIO: db_ms_inv_paquetes  (Stock de Envíos en Bodega)
--  Base de datos propia · Oracle 21c
--
--  Referencias externas (Ref Ext — sin FK formal):
--    INVENTARIO_PAQUETE.id_guia      → db_ms_tracking.GUIA_DESPACHO
--    INVENTARIO_PAQUETE.id_sucursal  → db_ms_sucursales.SUCURSAL
-- =============================================================

CREATE SEQUENCE seq_inventario_paquete START WITH 1 NOCACHE ORDER;

-- ----

CREATE TABLE inventario_paquete (
    id_inv        NUMBER(10)               DEFAULT seq_inventario_paquete.NEXTVAL NOT NULL,
    id_guia       NUMBER(10)               NOT NULL,  -- Ref Ext → db_ms_tracking.GUIA_DESPACHO
    id_sucursal   NUMBER(10)               NOT NULL,  -- Ref Ext → db_ms_sucursales.SUCURSAL
    fecha_ingreso TIMESTAMP WITH TIME ZONE DEFAULT SYSTIMESTAMP NOT NULL,
    fecha_salida  TIMESTAMP WITH TIME ZONE,
    CONSTRAINT pk_inventario_paquete PRIMARY KEY (id_inv)
);

COMMENT ON TABLE  inventario_paquete             IS 'Paquetes fisicamente almacenados en bodega de una sucursal';
COMMENT ON COLUMN inventario_paquete.id_guia     IS 'Ref Ext: id en db_ms_tracking.GUIA_DESPACHO';
COMMENT ON COLUMN inventario_paquete.id_sucursal IS 'Ref Ext: id en db_ms_sucursales.SUCURSAL';

CREATE INDEX idx_inv_guia     ON inventario_paquete (id_guia);
CREATE INDEX idx_inv_sucursal ON inventario_paquete (id_sucursal);

CREATE OR REPLACE TRIGGER inventario_paquete_trg
BEFORE INSERT ON inventario_paquete FOR EACH ROW WHEN (new.id_inv IS NULL)
BEGIN :new.id_inv := seq_inventario_paquete.nextval; END;
/

-- =============================================================
--  RESUMEN: 1 tabla · 1 sequence · 1 trigger · 2 índices
-- =============================================================
